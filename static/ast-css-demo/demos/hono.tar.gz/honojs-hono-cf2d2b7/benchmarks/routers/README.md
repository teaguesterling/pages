# Router benchmarks

Benchmark of the most commonly used HTTP routers.

Tested routes:

- [find-my-way](https://github.com/delvedor/find-my-way)
- [express](https://www.npmjs.com/package/express)
- [koa-router](https://github.com/alexmingoia/koa-router)
- [koa-tree-router](https://github.com/steambap/koa-tree-router)
- [trek-router](https://www.npmjs.com/package/trek-router)
- [@medley/router](https://www.npmjs.com/package/@medley/router)
- [Hono RegExpRouter](https://github.com/honojs/hono)
- [Hono TrieRouter](https://github.com/honojs/hono)

Install:

```
bun install --frozen-lockfile
```

For Node.js:

```
bun run bench:node
```

For Bun:

```
bun run bench:bun
```

This project is heavily inspired by [delvedor/router-benchmark](https://github.com/delvedor/router-benchmark)

## License

MIT
